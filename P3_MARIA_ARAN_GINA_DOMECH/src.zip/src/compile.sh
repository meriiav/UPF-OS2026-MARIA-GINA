#!/bin/bash
gcc P3_Parallel.c parsePGM.c -o computeHistogramParallel -lpthread