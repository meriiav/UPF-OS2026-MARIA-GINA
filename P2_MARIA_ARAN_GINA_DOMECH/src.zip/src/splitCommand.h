#include <stdlib.h>
#include <string.h>


char **split_command(char *line);