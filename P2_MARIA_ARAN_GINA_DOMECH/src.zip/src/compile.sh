#!/bin/bash
gcc -o myShell shell.c splitCommand.c
