#!/bin/bash
gcc src/program.c src/circularBuffer.c -o program
